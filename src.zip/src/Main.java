
import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

//ě š č ř ž ý á í é 
//Ě Š Č Ř Ž Ý Á Í É ú ů Ú Ů
public class Main extends Application{

    public static void main(String[] args) {
        Main.launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception {
        Node n = new HBox();
        Node n2 = new BorderPane();
    }
    public static Alert getAlert(AlertType type, String title, String headerText, String content, Node graphics) {
        Alert tmp = new Alert(type);
        tmp.setTitle(title);
        tmp.setHeaderText(headerText);
        tmp.setContentText(content);
        tmp.getDialogPane().setContent(graphics);
        return tmp;
    }


}
