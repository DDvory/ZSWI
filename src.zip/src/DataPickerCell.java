import javafx.scene.control.TableCell;


public class DataPickerCell extends TableCell<Row, String> {
	
	public void updateItem(String item, boolean empty) {
		super.updateItem(item, empty);
		
		if (empty) {
			setText(null);
			setGraphic(null);
		} else {
			System.out.println(item);//upravit
			setText(getItem().toString());
			setGraphic(null);
		}
	}
}
