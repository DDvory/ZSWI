import java.util.List;

import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class Window extends ASelectable {
	private String name;
	private Load load;
	private List<Window> window;
	private Panel panel;
        
	private TreeItem<Window> treeItem;

    public Window(int ID,String name, Load load, List<Window> window, Panel panel) {
        super(ID);
        this.name = name;
        this.load = load;
        this.window = window;
        this.panel = panel;
        if(panel != null) panel.setWindow(this);
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    public void setLoad(Load load) {
        this.load = load;
    }

    public Load getLoad() {
        return load;
    }

    public List<Window> getWindow() {
        return window;
    }

    public void setPanel(Panel panel) {
		this.panel = panel;
	}
    
    public Panel getPanel() {
    	return panel;
    }

    public TreeItem<Window> getTreeItem(){
        treeItem = new TreeItem<Window>(this);
        
        treeItem.addEventHandler(MouseEvent.ANY, new EventHandler<MouseEvent>() {//nefunguje
        	@Override
		    public void handle(MouseEvent mouseEvent) {
		        if(mouseEvent.getClickCount() == 2 && mouseEvent.getButton() == MouseButton.PRIMARY) {
		        	editTreeItem(treeItem);
		        }
		        if(mouseEvent.getButton() == MouseButton.SECONDARY) {
		        	createContextMenu(treeItem, mouseEvent.getX(), mouseEvent.getY());
		        }
		    }
        });
        
        for (Window win : window) {
            treeItem.getChildren().add(win.getTreeItem());
        }
        return treeItem;
    }
    
    @Override
    public Node getView() {
        return null;
    }        
    
	private static void createContextMenu(TreeItem<Window> selectedItem, double x, double y) {
		ContextMenu contextMenu = new ContextMenu();
		
	    MenuItem editItem;
	    if(selectedItem == GUIManager.getTreeView().getRoot()) {
	    	editItem = new MenuItem("Upravit Projekt");
	    } else {
	    	editItem = new MenuItem("Upravit Okno");
	    }
	    editItem.setOnAction(event -> editTreeItem(selectedItem));
	    
	    MenuItem addItem = new MenuItem("P�idat v�tev");
	    addItem.setOnAction(event -> GUIManager.createTreeItem(selectedItem));
	    
	    contextMenu.getItems().addAll(editItem, addItem);
	    contextMenu.setX(x);
	    contextMenu.setY(y);
	    
	    contextMenu.show(GUIManager.getPrimaryStage());
	}

	private static void editTreeItem(TreeItem<Window> selectedItem) {
		Stage newStage = new Stage();
		
		if(selectedItem == GUIManager.getTreeView().getRoot()) {
			newStage.setTitle("Upravit Projekt");	        
			Scene scene = new Scene(getEditTreeItemGridPane(newStage, selectedItem, true), 350, 350);
			newStage.setScene(scene);			
		} else {
			newStage.setTitle("Upravit Okno");	        
			Scene scene = new Scene(getEditTreeItemGridPane(newStage, selectedItem, false), 350, 350);
			newStage.setScene(scene);
		}
		newStage.show();
	}
	
	private static Parent getEditTreeItemGridPane(Stage newStage, TreeItem<Window> selectedItem, boolean withProject) {
		ComboBox<String> comboBox = new ComboBox<String>();
		
		Load[] loads = Load.values();
        for (Load load : loads) {
        	comboBox.getItems().add(load.toString());
        }
        
        TextField name, font, language;
        Button button;
        
		GridPane gridPane = new GridPane();
		
		gridPane.add(name = new TextField(selectedItem.getValue().getName()), 1, 0);
		gridPane.add(new Label("Typ na��t�n�: "), 0, 1);
		gridPane.add(comboBox, 1, 1);
		comboBox.getSelectionModel().select(selectedItem.getValue().getLoad().toString());
		gridPane.add(button = new Button("Upravit"), 1, 4);
		
		if(withProject) {
			gridPane.add(new Label("N�zev projektu: "), 0, 0);
			gridPane.add(new Label("Velikost p�sma: "), 0, 2);
			gridPane.add(font = new TextField(((Project) selectedItem.getValue()).getFont()), 1, 2);
			gridPane.add(new Label("Jazyk: "), 0, 3);
			gridPane.add(language = new TextField(((Project) selectedItem.getValue()).getLanguage()), 1, 3);
			
			button.setOnAction(event -> {
				if(name.getText().compareToIgnoreCase("") == 0 || font.getText().compareToIgnoreCase("") == 0
				|| language.getText().compareToIgnoreCase("") == 0
				|| comboBox.getSelectionModel().getSelectedIndex() == -1) {
					GUIManager.getAlert(AlertType.ERROR, "Upravov�n� Projektu", "�patn� parametry", "", null).show();
					return;
				}

				selectedItem.getValue().setName(name.getText());
				selectedItem.getValue().setLoad(Load.getLoad(comboBox.getSelectionModel().getSelectedItem()));
				((Project)selectedItem.getValue()).setFont(font.getText());
				((Project)selectedItem.getValue()).setLanguage(language.getText());
				GUIManager.getTreeView().refresh();
				newStage.close();
			});
		} else {
			gridPane.add(new Label("N�zev Okna: "), 0, 0);
			button.setOnAction(event -> {
				if(name.getText().compareToIgnoreCase("") == 0
				|| comboBox.getSelectionModel().getSelectedIndex() == -1) {
					GUIManager.getAlert(AlertType.ERROR, "Upravov�n� Okna", "�patn� parametry", "", null).show();
					return;
				}

				selectedItem.getValue().setName(name.getText());
				selectedItem.getValue().setLoad(Load.getLoad(comboBox.getSelectionModel().getSelectedItem()));
				GUIManager.getTreeView().refresh();
				newStage.close();
			});		
		}		
		return gridPane;
	}

}
