﻿import java.io.File;
import java.util.ArrayList;
import java.util.Optional;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


public class GUIManager extends Application {//okna zobrazovat (nevytvaret furt novy), osetrit pri vymecnych pripadech
	//pridavani panelu apod. (vyskoci info atd.)
	
	private static Stage primaryStage;
	private static SplitPane splitPane;
	private static GUIManager INSTANCE;
	private static boolean editMode = false;
	
	private static TreeView<Window> treeView;
	private static BorderPane mainBorderPane;
	private static HBox botHBox;
	 
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		INSTANCE = this;
		GUIManager.primaryStage = primaryStage;
		
		setUpTreeView();
		setUpMainBorderPane();
		setUpBotBorderPane();
		setIcon(primaryStage);
		
		primaryStage.setTitle("<- Zkouška.");
		primaryStage.setScene(createScene());
		
		primaryStage.show();
		/*
		//zk		
		Project project = new Project(0, "ZK", Load.NEVER,		
				new ArrayList<Window>(), new Panel(0,  new ArrayList<Table>()), "12", "CZ", new ArrayList<String>());
		showProject(project);
		addTable(treeView.getSelectionModel().getSelectedItem());
		//zk*/
	}

	private void setIcon(Stage stage) {
		try {
			stage.getIcons().add(new Image("/data/icon.png"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void setUpTreeView() {
		treeView = new TreeView<Window>();
		
		treeView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

		treeView.getSelectionModel().getSelectedItems().addListener((ListChangeListener.Change<? extends TreeItem<Window>> change) -> {
			if(treeView.getSelectionModel().getSelectedItem() != null) { //potřeba - při změně kořene na to reaguje a hází chybu (null)
				changePanel(treeView.getSelectionModel().getSelectedItem(), 
						treeView.getSelectionModel().getSelectedItem().getValue().getPanel());
			}
		});
		
		treeView.setCellFactory(treeView -> {
			return new TreeDisplayCell();
		});
		treeView.setRoot(new TreeItem<Window>(null));
	}

	private static void setUpMainBorderPane() {
		mainBorderPane = new BorderPane();
		mainBorderPane.setStyle(Constants.borderStyle1);
		
		mainBorderPane.setOnMouseClicked(new EventHandler<MouseEvent>() {
        	@Override
		    public void handle(MouseEvent mouseEvent) {
		        if(mouseEvent.getClickCount() == 2 && mouseEvent.getButton() == MouseButton.PRIMARY) {
		        	if(treeView.getSelectionModel().getSelectedItem().getValue().getPanel() == null) {
		        		createPanel(treeView.getSelectionModel().getSelectedItem());
		        	}
		        }
		        if(mouseEvent.getButton() == MouseButton.SECONDARY) {
		        	createContextMenu(mouseEvent.getScreenX(), mouseEvent.getScreenY());
		        }
        	}
		});
	}

	private static void setUpBotBorderPane() {
		botHBox = new HBox();
		botHBox.setStyle(Constants.borderStyle1);
		BorderPane.setMargin(botHBox, new Insets(5));
	}
	
	private static void changePanel(TreeItem<Window> treeItem, Panel panel) {
		if(panel != null) {
			treeItem.getValue().setPanel(panel);
			panel.setWindow(treeItem.getValue());
			mainBorderPane.setCenter(panel.getView());
		} else {
			mainBorderPane.setCenter(null);
		}
	}

	private static void createContextMenu(double x, double y) {
		ContextMenu contextMenu = new ContextMenu();
		
	    MenuItem addItem = new MenuItem("Přidat Panel");
	    addItem.setOnAction(event -> createPanel(treeView.getSelectionModel().getSelectedItem()));
	    
	    contextMenu.getItems().add(addItem);
	    contextMenu.setX(x);
	    contextMenu.setY(y);
	    
	    contextMenu.show(GUIManager.getPrimaryStage());
	}
	
	private static void createPanel(TreeItem<Window> treeItem) {
		Panel panel = new Panel(0, new ArrayList<Table>());
		changePanel(treeItem, panel);
	}

	private static Scene createScene() {
		Scene scene = new Scene(getRoot(), 750, 500);
		return scene;
	}

	private static Parent getRoot() {
		BorderPane borderPane = new BorderPane();

		borderPane.setTop(createMenu());
		borderPane.setCenter(createMainPane());
		borderPane.setBottom(createBottom(null));
		
		return borderPane;
	}
	
	//-----------------------------------------------------------------------------------------------------------------

	private static Node createMenu() {
		MenuBar menuBar = new MenuBar();
		
		Menu fileMenu = new Menu("_Soubor");
		MenuItem newItem = new MenuItem("_Nový");
		MenuItem openItem = new MenuItem("_Otevřít");
		MenuItem saveItem = new MenuItem("_Uložit");
		MenuItem saveAsItem = new MenuItem("Uložit _Jako");
		MenuItem importItem = new MenuItem("_Importovat Jazyk");
		MenuItem exportItem = new MenuItem("_Exportovat Jazyk");

		newItem.setOnAction(event -> createTreeItem(null));
		openItem.setOnAction(event -> loadProject());
		//saveItem.setOnAction(event -> );
		//saveAsItem.setOnAction(event -> );
		//importItem.setOnAction(event -> );
		//exportItem.setOnAction(event -> );
		
		fileMenu.getItems().addAll(
				newItem, openItem, new SeparatorMenuItem(), 
				saveItem, saveAsItem, new SeparatorMenuItem(), 
				importItem, exportItem);

		Menu editMenu = new Menu("_Upravit");
		MenuItem treeItem = new MenuItem("Přidat _Větev");
		MenuItem panelItem = new MenuItem("Přidat _Panel");
		MenuItem tableItem = new MenuItem("Přidat _Tabulku");

		treeItem.setOnAction(event -> createTreeItem(treeView.getSelectionModel().getSelectedItem()));
		panelItem.setOnAction(event -> createPanel(treeView.getSelectionModel().getSelectedItem()));
		tableItem.setOnAction(event -> addTable(treeView.getSelectionModel().getSelectedItem()));
		
		editMenu.getItems().addAll(
				treeItem, panelItem, tableItem);
		
		menuBar.getMenus().addAll(fileMenu, editMenu);
		return menuBar;
	}

	private static Node createMainPane() {
		splitPane = new SplitPane();
		
		splitPane.getItems().addAll(createEmtyTreeView(), createEmptyPanelPane());
		
		splitPane.setDividerPositions(0.33);
		SplitPane.setResizableWithParent(splitPane.getItems().get(0), false);
		SplitPane.setResizableWithParent(splitPane.getItems().get(1), false);
		
		return splitPane;
	}
	
	private static Node createBottom(Project project) {		
		if(project == null) {
			botHBox.getChildren().clear();
		} else {
			botHBox.getChildren().add(new Label("Velikost písma: "));		
			Label fontLabel = new Label(project.getFont());
			fontLabel.setOnMouseClicked(new EventHandler<MouseEvent>() {
			    @Override
			    public void handle(MouseEvent mouseEvent) {            
			        if(mouseEvent.getClickCount() == 2) {
			        	changeFont(fontLabel, project);
			        }
			    }
			});
			botHBox.getChildren().add(fontLabel);
			
			botHBox.getChildren().add(new Label(" | "));
			
			botHBox.getChildren().add(new Label("Jazyk: "));
			Label langLabel = new Label(project.getLanguage());
			langLabel.setOnMouseClicked(new EventHandler<MouseEvent>() {
			    @Override
			    public void handle(MouseEvent mouseEvent) {            
			        if(mouseEvent.getClickCount() == 2) {
			        	changeLanguage(langLabel, project);
			        }
			    }
			});
			botHBox.getChildren().add(langLabel);
		}
		return botHBox;
	}
	
	private static void changeFont(Label label, Project project) {
		TextField textField = new TextField(label.getText());
		
		HBox hBox = (HBox) label.getParent();
		
		textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
	        @Override
	        public void handle(KeyEvent ke) {
	            if (ke.getCode().equals(KeyCode.ENTER))  {
	            	project.setFont(textField.getText());
	            	label.setText(textField.getText());
	            	exchange(hBox, 1, label);
	            } else if (ke.getCode().equals(KeyCode.ESCAPE))  {
	            	exchange(hBox, 1, label);
	            }
	        }
	    });
		
		textField.focusedProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            	if(!newValue) {
            		exchange(hBox, 1, label);
            	}
            }
        });
		
		exchange(hBox, 1, textField);
		textField.requestFocus();
	}
	
	private static void changeLanguage(Label label, Project project) {
		TextField textField = new TextField(label.getText());
		
		HBox hBox = (HBox) label.getParent();
		
		textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
	        @Override
	        public void handle(KeyEvent ke) {
	            if (ke.getCode().equals(KeyCode.ENTER))  {
	            	project.setLanguage(textField.getText());
	            	label.setText(textField.getText());
	            	exchange(hBox, 4, label);
	            } else if (ke.getCode().equals(KeyCode.ESCAPE))  {
	            	exchange(hBox, 4, label);
	            }
	        }
	    });
		
		textField.focusedProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            	if(!newValue) {
            		exchange(hBox, 4, label);
            	}
            }
        });
		
		exchange(hBox, 4, textField);
		textField.requestFocus();
	}
	
	private static void exchange(HBox hBox, int i, Node node) {
		hBox.getChildren().remove(i);
		hBox.getChildren().add(i, node);
	}
	
	//-----------------------------------------------------------------------------------------------------------------

	private static Node createEmtyTreeView() {
		treeView.setRoot(null);
		return treeView;
	}

	private static Node createEmptyPanelPane() {
		mainBorderPane.setCenter(null);
		mainBorderPane.setTop(null);
		mainBorderPane.setLeft(null);
		mainBorderPane.setRight(null);
		mainBorderPane.setBottom(null);
		return mainBorderPane;
	}
		
	//-----------------------------------------------------------------------------------------------------------------

	private static void loadProject() {
		String adress = getAdress();
		if(adress == null) return;
		
		Project project = new XmlManager().ReadXML(adress);
		
		showProject(project);
	}
	
	@SuppressWarnings("unchecked")
	private static void showProject(Project project) {
		TreeView<Window> temp = (TreeView<Window>) project.getView();
		treeView.setRoot(temp.getRoot());
		treeView.getSelectionModel().select(temp.getRoot());
		
		changePanel(treeView.getSelectionModel().getSelectedItem(), project.getPanel());
		createBottom(project);
	}
	
    private static String getAdress() {
    	String adress = null;
        HBox box = new HBox();
        TextField textField = new TextField();
        Button button = new Button("Procházet");
        button.setOnMouseClicked(eh -> {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(getPrimaryStage());
            if (file != null) {
                textField.setText(file.getAbsolutePath());
            }
        });
        box.getChildren().addAll(textField, new Label(" "), button);
        Optional<ButtonType> alert = getAlert(AlertType.CONFIRMATION, "Prohledávání", "Vyber cestu k souboru", "", box).showAndWait();
        if (alert.get() == ButtonType.OK) {
            adress = textField.getText();
            if (adress.length() == 0) {
                adress = null;
            }
        }
        if (adress == null) {
        	getAlert(AlertType.ERROR, "Prohledávání", "Soubor nenalezen", "", null).show();
        }
        return adress;
    }
	
	public static Alert getAlert(AlertType type, String title, String headerText, String content, Node graphics) {
        Alert tmp = new Alert(type);
        tmp.setTitle(title);
        tmp.setHeaderText(headerText);
        tmp.setContentText(content);
        tmp.getDialogPane().setContent(graphics);
        return tmp;
    }

	//-----------------------------------------------------------------------------------------------------------------

	private static void addTable(TreeItem<Window> selectedItem) {
		if(selectedItem == null) {
			getAlert(AlertType.ERROR, "Přidávání Tabulky", "Nebylo vybráno okno či projekt", "", null).show();
		} else {
			Stage newStage = new Stage();
			
			newStage.setTitle("Nová tabulka");        
			Scene scene = new Scene(getAddTableGridPane(newStage, selectedItem), 350, 350);
			newStage.setScene(scene);
			
			newStage.show();
		}
	}
	
	private static void addTreeItem(TreeItem<Window> parent, TreeItem<Window> newItem) {
		parent.getChildren().add(newItem);
		treeView.getSelectionModel().select(newItem);
	}

	public static void createTreeItem(TreeItem<Window> selectedItem) {
		Stage newStage = new Stage();
		
		if(selectedItem == null) {
			newStage.setTitle("Nový Projekt");        
			Scene scene = new Scene(getCreateTreeItemGridPane(newStage, selectedItem, true), 350, 350);
			newStage.setScene(scene);			
		} else {
			newStage.setTitle("Nové Okno");        
			Scene scene = new Scene(getCreateTreeItemGridPane(newStage, selectedItem, false), 350, 350);
			newStage.setScene(scene);
		}
		
		newStage.show();
	}
	
	//-----------------------------------------------------------------------------------------------------------------
	
	private static Parent getCreateTreeItemGridPane(Stage newStage, TreeItem<Window> selectedItem, boolean withProject) {
		ComboBox<String> comboBox = new ComboBox<String>();
		
		Load[] loads = Load.values();
        for (Load load : loads) {
        	comboBox.getItems().add(load.toString());
        }
        
        TextField name, font, language;
        Button button;
        
		GridPane gridPane = new GridPane();
		gridPane.add(name = new TextField(), 1, 0);
		gridPane.add(new Label("Typ načítání: "), 0, 1);
		gridPane.add(comboBox, 1, 1);
		gridPane.add(button = new Button("Vytvořit"), 1, 4);
		
		if(withProject) {
			gridPane.add(new Label("Název projektu: "), 0, 0);
			gridPane.add(new Label("Velikost písma: "), 0, 2);
			gridPane.add(font = new TextField(), 1, 2);
			gridPane.add(new Label("Jazyk: "), 0, 3);
			gridPane.add(language = new TextField(), 1, 3);
			
			button.setOnAction(event -> {
				if(name.getText().compareToIgnoreCase("") == 0 || font.getText().compareToIgnoreCase("") == 0
				|| language.getText().compareToIgnoreCase("") == 0
				|| comboBox.getSelectionModel().getSelectedIndex() == -1) {
					getAlert(AlertType.ERROR, "Nový Projekt", "Špatné parametry", "", null).show();
					return;
				}
	
				Project temp = new Project(0, name.getText(), Load.getLoad(comboBox.getSelectionModel().getSelectedItem()),
						new ArrayList<Window>(), null, font.getText(), language.getText(), new ArrayList<String>());
				showProject(temp);
				newStage.close();
			});
		} else {
			gridPane.add(new Label("Název Okna: "), 0, 0);
			button.setOnAction(event -> {
				if(name.getText().compareToIgnoreCase("") == 0
				|| comboBox.getSelectionModel().getSelectedIndex() == -1) {
					getAlert(AlertType.ERROR, "Nové Okno", "Špatné parametry", "", null).show();
					return;
				}
	
				Window temp = new Window(0, name.getText(), Load.getLoad(comboBox.getSelectionModel().getSelectedItem()),
						new ArrayList<Window>(), null);
				addTreeItem(selectedItem, temp.getTreeItem());
				newStage.close();
			});
		}
		
		return gridPane;
	}
	
	private static Parent getAddTableGridPane(Stage newStage, TreeItem<Window> selectedItem) {
		TextField name, columnCount;
        
		GridPane gridPane = new GridPane();
		gridPane.add(new Label("Název Tabulky: "), 0, 0);
		gridPane.add(name = new TextField(), 1, 0);
		gridPane.add(new Label("Počet sloupců: "), 0, 1);
		gridPane.add(columnCount = new TextField(), 1, 1);
		columnCount.textProperty().addListener((observable, oldValue, newValue) -> {
			int temp = Integer.valueOf(columnCount.getText());
	        Button button;
	        TextField[] columnNames = new TextField[temp];
	        
	        gridPane.getChildren().remove(4, gridPane.getChildren().size());
			for(int i = 0; i < temp; i++) {
				gridPane.add(new Label("Název sloupce " + (i+1)), 0, 2+i);
				gridPane.add(columnNames[i] = new TextField(), 1, 2+i);
			}
			gridPane.add(button = new Button("Vytvořit"), 1, 2+temp);
			
			button.setOnAction(event -> {
				ArrayList<Row> columnNamesList = new ArrayList<Row>();
				Item[] items = new Item[temp];
				
				if(name.getText().compareToIgnoreCase("") == 0 || columnCount.getText().compareToIgnoreCase("") == 0) {
					getAlert(AlertType.ERROR, "Nová Tabulka", "Špatné parametry", "", null).show();
					return;
				}
				for(int i = 0; i < temp; i++) {
					items[i] = new Item(0, columnNames[i].getText(), Meter.none);
					if(columnNames[i].getText().compareToIgnoreCase("") == 0) {
						getAlert(AlertType.ERROR, "Nová Tabulka", "Špatné parametry", "", null).show();
						return;
					}
				}
				columnNamesList.add(new Row(0, items));

				treeView.getSelectionModel().getSelectedItem().getValue().getPanel().addTable(
						new Table(0, name.getText(), temp, FXCollections.observableList(columnNamesList)));
				
				Panel panel = treeView.getSelectionModel().getSelectedItem().getValue().getPanel();

				splitPane.getItems().add(panel.getView());
				splitPane.getItems().remove(1);
				
				newStage.close();
			});
		});
		return gridPane;
	}

	//-----------------------------------------------------------------------------------------------------------------
	
	public static GUIManager getINSTANCE() {
		return INSTANCE;
	}

	
	public static Stage getPrimaryStage() {
		return primaryStage;
	}
	
	public static TreeView<Window> getTreeView() {
		return treeView;
	}
}
