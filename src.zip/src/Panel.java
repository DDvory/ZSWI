
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;



public class Panel extends ASelectable {
    private List<Table> tables;
	
    private VBox view_Box;
    
    private Window window;

    public Panel(int ID,List<Table> tables) {
        super(ID);
        this.tables = tables;
    }
    
    public void addTable(Table table) {
    	tables.add(table);
    }
    
    @Override
    public Node getView() {
    	BorderPane borderPane = new BorderPane();
		borderPane.setStyle(Constants.borderStyle1);
		BorderPane.setMargin(borderPane, new Insets(5));
		
		borderPane.setTop(createTop(window.getName()));
		borderPane.setCenter(createList());
		return borderPane;
    }

	public void setWindow(Window window) {
        this.window = window;		
	}
    
    public Window getWindow() {
    	return window;
    }
    
    private Node createList() {
    	ScrollPane scrollPane = new ScrollPane();
    	
		VBox vBox = new VBox();
		vBox.setSpacing(20);
		vBox.setStyle(Constants.borderStyle2);
		
		for(int i = 0; i < tables.size(); i++) {
			vBox.getChildren().add(tables.get(i).getView());
		}

		scrollPane.setContent(vBox);
		return scrollPane;
	}	
    
	private Node createTop(String name) {
		BorderPane borderPane = new BorderPane();
		borderPane.setStyle(Constants.borderStyle4);

		borderPane.setLeft(createLeft(name));
		return borderPane;
	}
	
	private Node createLeft(String name) {
		Label label = new Label(name);
		label.setPadding(new Insets(5));
		
		label.setOnMouseClicked(new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent mouseEvent) {            
		        if(mouseEvent.getClickCount() == 2) {
		        	changeText(label);
		        }
		    }
		});	
		return label;
	}
	
	private void changeText(Label label) {
		TextField textField = new TextField(label.getText());
		
		BorderPane borderPane = (BorderPane) label.getParent();
		
		textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
	        @Override
	        public void handle(KeyEvent ke) {
	            if (ke.getCode().equals(KeyCode.ENTER))  {
	            	window.setName(textField.getText());
	            	GUIManager.getTreeView().refresh();
	            	label.setText(textField.getText());
	        		borderPane.setLeft(label);
	            } else if (ke.getCode().equals(KeyCode.ESCAPE))  {
	        		borderPane.setLeft(label);
	            }
	        }
	    });
		
		textField.focusedProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            	if(!newValue) {
            		borderPane.setLeft(label);
            	}
            }
        });
		
		borderPane.setLeft(textField);
		textField.requestFocus();
	}
         
}
