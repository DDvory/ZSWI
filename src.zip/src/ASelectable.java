
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javafx.scene.Node;

public abstract class ASelectable {

    private int ID;

    public ASelectable(int ID) {
        this.ID = ID;
    }
    

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    public abstract Node getView();
}
