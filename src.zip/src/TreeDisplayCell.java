import javafx.scene.control.TreeCell;


public class TreeDisplayCell extends TreeCell<Window> {
	
    public void updateItem(Window item, boolean empty) { 
        super.updateItem(item, empty); 

        if (empty) { 
            setText(null); 
            setGraphic(null);     
        } else {
            setText(item.getName()); 
            setGraphic(null);
        } 
    } 
}
