/**
 *
 * @author DDvory
 */
public class Constants {
    public static final String Project = "Project";
    public static final String RegsitredLanguage = "RegsitredLanguage";
    public static final String Window = "Window";
    public static final String Row = "Row";
    public static final String Item = "Item";
    public static final String Table = "Table";
    public static final String Panel = "Panel";
    ///////////////////////////////////////////////
    public static final String name = "name";
    public static final String language = "language";
    public static final String value = "value";
    public static final String load = "load";
    public static final String id = "id";
    public static final String columns = "columns";
    public static final String dataType = "dataType";
    public static final String meter = "meter";
    public static final String fontSize = "fontSize";
    

    public static String borderStyle1 = "-fx-padding: 4;" + 
			//"-fx-border-style: solid inside;" + 
			"-fx-border-width: 0;" +
			//"-fx-border-color: black;" +
			"-fx-background-color: #AAB8ED;";
    public static String borderStyle2 = "-fx-padding: 4;" + 
			//"-fx-border-style: solid inside;" + 
			"-fx-border-width: 0;" +
			//"-fx-border-color: black;" +
			"-fx-background-color: #DEE0E9;";
    public static String borderStyle3 = "-fx-padding: 4;" + 
			//"-fx-border-style: solid inside;" + 
			"-fx-border-width: 0;" +
			//"-fx-border-color: black;" +
			"-fx-background-color: #F7F7F7;";
	public static String borderStyle4 = "-fx-padding: 4;" + 
			//"-fx-border-style: solid inside;" + 
			"-fx-border-width: 0;" +
			//"-fx-border-color: black;" +
			"-fx-background-color: #FFFFFF;";
    
}
