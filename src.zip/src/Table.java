import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.util.Callback;

/**
 *
 * @author DDvory
 */
public class Table extends ASelectable {
    private String name;
    private int columnCount;
    private ObservableList<Row> listRow;
    
    private Label view_name;
    private TableView<Row> tableView;

    public Table(int ID,String name, int columnCount, ObservableList<Row> listRow) {
        super(ID);
        this.name = name;
        this.columnCount = columnCount;
        this.listRow = listRow;
    }
    
    @Override
    public Node getView() {
    	BorderPane borderPane = new BorderPane();
		borderPane.setStyle(Constants.borderStyle1);
		BorderPane.setMargin(borderPane, new Insets(5));
		
		borderPane.setTop(createTop(name));
		borderPane.setCenter(createTable());
		borderPane.setBottom(createBot());
		return borderPane;
    }

	private Node createTable() {
    	tableView = new TableView<Row>();
		tableView.setFixedCellSize(25);
	    tableView.prefHeightProperty().bind(tableView.fixedCellSizeProperty().multiply(Bindings.size(tableView.getItems()).add(1.01)));
	    tableView.minHeightProperty().bind(tableView.prefHeightProperty());
	    tableView.maxHeightProperty().bind(tableView.prefHeightProperty());
	    
	    for(int i = 0; i < columnCount; i++) {
		    TableColumn<Row, String> temp = new TableColumn<Row, String>(listRow.get(0).getItems(i).getData("type"));
		    /*
		    temp.setCellFactory(new Callback<TableColumn<Row, String>, TableCell<Row, String>>() {
				@Override
				public TableCell<Row, String> call(TableColumn<Row, String> param) {
					return new DataPickerCell();
				}
			});
			temp.setCellFactory(TextFieldTableCell.forTableColumn());*/
	    	
		    temp.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Row, String>, ObservableValue<String>>() {

	    	    @Override
	    	    public ObservableValue<String> call(TableColumn.CellDataFeatures<Row, String> p) {
	    	        if (p.getValue() != null) {
	    	            return new SimpleStringProperty(p.getValue().toString());
	    	        } else {
	    	            return new SimpleStringProperty("<no name>");
	    	        }
	    	    }
	    	});
		    
		    tableView.getColumns().add(temp);
	    }
	    
	    tableView.setItems(listRow);
	    
		return tableView;
	}
    
    private Node createBot() {
    	HBox hBox = new HBox();
    	
    	Button editButton = new Button("Upravit Tabulku");
    	Button addButton = new Button("P�idat ��dek");
    	Button addEmtyButton = new Button("P�idat Pr�zdn� ��dek");
    	addEmtyButton.setOnAction(event -> addRow());
    	
		hBox.getChildren().addAll(addButton, addEmtyButton, editButton);
    	
		return hBox;
	}

	private void addRow() {
		Item[] items = new Item[tableView.getColumns().size()];
		
		for (int i = 0; i < items.length; i++) {
			items[i] = new Item(0, null, null);
		}
		
		listRow.add(new Row(0, items));
	}

	private Node createTop(String name) {
		BorderPane borderPane = new BorderPane();
		borderPane.setStyle(Constants.borderStyle4);

		borderPane.setLeft(createLeft(name));
		return borderPane;
	}
	
	private Node createLeft(String name) {
		Label label = new Label(name);
		label.setPadding(new Insets(5));
		
		label.setOnMouseClicked(new EventHandler<MouseEvent>() {
		    @Override
		    public void handle(MouseEvent mouseEvent) {            
		        if(mouseEvent.getClickCount() == 2) {
		        	changeText(label);
		        }
		    }
		});
		
		return label;
	}
	
	private void changeText(Label label) {
		TextField textField = new TextField(label.getText());
		
		BorderPane borderPane = (BorderPane) label.getParent();
		
		textField.setOnKeyPressed(new EventHandler<KeyEvent>() {
	        @Override
	        public void handle(KeyEvent ke) {
	            if (ke.getCode().equals(KeyCode.ENTER))  {
	            	//window.setName(textField.getText());
	            	//dodelat nacteni /\
	            	label.setText(textField.getText());
	        		borderPane.setLeft(label);
	            } else if (ke.getCode().equals(KeyCode.ESCAPE))  {
	        		borderPane.setLeft(label);
	            }
	        }
	    });
		
		textField.focusedProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
            	if(!newValue) {
            		borderPane.setLeft(label);
            	}
            }
        });
		
		borderPane.setLeft(textField);
	}
}
