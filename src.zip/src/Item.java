
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalTime;

import javafx.scene.Node;
import javafx.scene.control.Label;

public class Item extends ASelectable {//externe rict - jak je dlouhy, pri STRingu orezavat
	//58 (zatim libovolne) -> 1, 2, 3 (pevne dany)

    private final String type;
    private final Label label;
    private final Meter meter;

    private String STRING = null;
    private LocalTime TIME = null;
    private LocalDate DATE = null;
    private Boolean BOOL = null;
    private Boolean BIT = null;
    private Byte INT8_T = null;
    private Short INT16_T = null;
    private Integer INT32_T = null;
    private Long INT64_T = null;
    private Short UINT8_T = null;
    private Integer UINT16_T = null;
    private Long UINT32_T = null;
    private BigInteger UINT64_T = null;
    private Float FLOAT = null;
    private Double DOUBLE = null;

    public Item(int ID,String type,Meter meter) {
        super(ID);
        this.type = type;
        this.label = new Label();
        this.meter = meter;
    }

    public void setToLabel() {
        label.setText(this.getData(null));
    }

    public Label getLabel() {
        return label;
    }
    
    public void setData(String arg0, String arg1) {
        try {
            Field field = this.getClass().getDeclaredField(arg0);
            field.setAccessible(true);

            if (!field.getType().equals(String.class)) {
                Class<?> dataType = field.getType();
                Method m = dataType.getDeclaredMethod("valueOf", String.class);
                m.setAccessible(true);

                Object o = m.invoke(this, arg1);
                field.set(this, dataType.cast(o));
            } else {
                field.set(this, arg1);
            }
        } catch (Exception e) { //(NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    public String getData(String arg0) {
        try {
            Field field = this.getClass().getDeclaredField(arg0);
            field.setAccessible(true);

            if (!field.getType().equals(String.class)) {
                return String.valueOf(field.get(this));
            } else {
                return (String) field.get(this);
            }
        } catch (Exception e) {//(IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
        }
        return "";
    }
    
    @Override
    public Node getView() {
        return null;
    }

}
