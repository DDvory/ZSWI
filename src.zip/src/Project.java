import java.util.List;

import javafx.scene.Node;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;


public class Project extends Window {
	private String fontSize;
	private String language;
	private List<String> registeredLanguages;
	
	private TreeView<Window> treeView;

    public Project(int ID, String name, Load load, List<Window> window, Panel panel,String fontSize, String language, List<String> registeredLanguages) {
        super(ID, name, load, window, panel);
        this.fontSize = fontSize;
        this.language = language;
        this.registeredLanguages = registeredLanguages;
    }
    
    @Override
    public Node getView() {
        TreeItem<Window> treeItem = this.getTreeItem();
        treeView = new TreeView<Window>(treeItem);		
		return treeView;
    }

	public void setLanguage(String language) {
		this.language = language;
	}
	
	public String getLanguage() {
		return language;
	}

	public void setFont(String fontSize) {
		this.fontSize = fontSize;
	}
	
	public String getFont() {
		return fontSize;
	}
}
